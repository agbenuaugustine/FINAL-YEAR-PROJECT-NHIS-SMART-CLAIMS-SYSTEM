<?php
// Include secure authentication middleware
require_once __DIR__ . '/secure_auth.php';

/**
 * Patient Registration Page
 * 
 * Handles patient registration
 */

// User data is now available from secure_auth.php
// $user and $role variables are already set
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Registration - Smart Claims</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* Apple-inspired styles */
        @import url('https://fonts.googleapis.com/css2?family=SF+Pro+Display:wght@300;400;500;600;700&display=swap');
        
        :root {
            --primary-color: #0071e3;
            --secondary-color: #06c;
            --success-color: #34c759;
            --warning-color: #ff9500;
            --danger-color: #ff3b30;
            --light-bg: #f5f5f7;
            --card-bg: #ffffff;
            --text-primary: #1d1d1f;
            --text-secondary: #86868b;
            --border-color: #d2d2d7;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'SF Pro Display', -apple-system, BlinkMacSystemFont, sans-serif;
        }
        
        body {
            background-color: var(--light-bg);
            color: var(--text-primary);
            line-height: 1.5;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }
        
        /* App container */
        .app-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 1rem;
        }
        
        /* Header */
        .app-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 0;
            margin-bottom: 1.5rem;
        }
        
        .app-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--text-primary);
            display: flex;
            align-items: center;
        }
        
        .app-logo {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #0f2b5b, #1e88e5);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.25rem;
            transform: rotate(10deg);
            box-shadow: 0 4px 8px rgba(30, 136, 229, 0.3);
            margin-right: 0.75rem;
        }
        
        /* Navigation */
        .app-nav {
            display: flex;
            background-color: rgba(255, 255, 255, 0.8);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            margin-bottom: 1.5rem;
            overflow: hidden;
            position: sticky;
            top: 1rem;
            z-index: 100;
        }
        
        .nav-item {
            flex: 1;
            padding: 0.75rem 1rem;
            text-align: center;
            color: var(--text-secondary);
            font-weight: 500;
            transition: all 0.2s ease;
            position: relative;
            white-space: nowrap;
        }
        
        .nav-item:hover {
            color: var(--primary-color);
        }
        
        .nav-item.active {
            color: var(--primary-color);
        }
        
        .nav-item.active::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 30px;
            height: 3px;
            background-color: var(--primary-color);
            border-radius: 3px;
        }
        
        .nav-item i {
            margin-right: 0.5rem;
            font-size: 1.1rem;
        }
        
        /* Cards */
        .card {
            background-color: var(--card-bg);
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            border: 1px solid rgba(0, 0, 0, 0.05);
        }
        
        /* Form elements */
        .form-section {
            margin-bottom: 2rem;
        }
        
        .form-section-title {
            font-size: 1.1rem;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
        }
        
        .form-section-title i {
            margin-right: 0.5rem;
            color: var(--primary-color);
        }
        
        .form-group {
            margin-bottom: 1.25rem;
        }
        
        .form-label {
            display: block;
            font-size: 0.875rem;
            font-weight: 500;
            color: var(--text-secondary);
            margin-bottom: 0.5rem;
        }
        
        .form-control {
            width: 100%;
            padding: 0.75rem 1rem;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            font-size: 1rem;
            color: var(--text-primary);
            background-color: var(--card-bg);
            transition: all 0.2s ease;
        }
        
        .form-control:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(0, 113, 227, 0.2);
        }
        
        .form-control::placeholder {
            color: #c7c7cc;
        }
        
        .form-hint {
            font-size: 0.75rem;
            color: var(--text-secondary);
            margin-top: 0.25rem;
        }
        
        /* Buttons */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 0.75rem 1.5rem;
            border-radius: 8px;
            font-weight: 500;
            transition: all 0.2s ease;
            cursor: pointer;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            color: white;
        }
        
        .btn-primary:hover {
            background-color: #0062c3;
        }
        
        .btn-outline {
            border: 1px solid var(--border-color);
            color: var(--text-primary);
        }
        
        .btn-outline:hover {
            background-color: rgba(0, 0, 0, 0.05);
        }
        
        .btn-icon {
            margin-right: 0.5rem;
        }
        
        /* User menu */
        .user-menu {
            position: relative;
        }
        
        .user-button {
            display: flex;
            align-items: center;
            background-color: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: 20px;
            padding: 0.25rem 0.75rem;
            cursor: pointer;
            transition: all 0.2s ease;
        }
        
        .user-button:hover {
            background-color: rgba(0, 0, 0, 0.05);
        }
        
        .user-avatar {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background-color: #e0e0e0;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 0.5rem;
            color: #666;
        }
        
        /* Page header */
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
        }
        
        .page-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--text-primary);
        }
        
        .page-actions {
            display: flex;
            gap: 0.75rem;
        }
        
        /* Mobile styles */
        @media (max-width: 768px) {
            .app-nav {
                display: none;
            }
            
            .mobile-nav {
                display: flex;
                position: fixed;
                bottom: 0;
                left: 0;
                right: 0;
                background-color: rgba(255, 255, 255, 0.9);
                backdrop-filter: blur(20px);
                -webkit-backdrop-filter: blur(20px);
                border-top: 1px solid var(--border-color);
                padding: 0.75rem 0.5rem;
                z-index: 100;
                justify-content: space-around;
            }
            
            .mobile-nav-item {
                display: flex;
                flex-direction: column;
                align-items: center;
                font-size: 0.75rem;
                color: var(--text-secondary);
                padding: 0.5rem;
                border-radius: 8px;
            }
            
            .mobile-nav-item.active {
                color: var(--primary-color);
            }
            
            .mobile-nav-item i {
                font-size: 1.25rem;
                margin-bottom: 0.25rem;
            }
        }
        
        /* Animated background */
        .animated-bg {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            overflow: hidden;
        }
        
        .bg-shape {
            position: absolute;
            border-radius: 50%;
            filter: blur(70px);
            opacity: 0.3;
        }
        
        .bg-shape-1 {
            width: 500px;
            height: 500px;
            background: linear-gradient(135deg, #0071e3, #34c759);
            top: -200px;
            left: -200px;
            animation: float 25s infinite ease-in-out;
        }
        
        .bg-shape-2 {
            width: 400px;
            height: 400px;
            background: linear-gradient(135deg, #5ac8fa, #007aff);
            bottom: -150px;
            right: -150px;
            animation: float 20s infinite ease-in-out reverse;
        }
        
        @keyframes float {
            0% {
                transform: translate(0, 0) rotate(0deg);
            }
            50% {
                transform: translate(50px, 50px) rotate(10deg);
            }
            100% {
                transform: translate(0, 0) rotate(0deg);
            }
        }
        
        /* Form progress indicator */
        .form-progress {
            display: flex;
            margin-bottom: 2rem;
            overflow-x: auto;
            padding-bottom: 0.5rem;
        }
        
        .progress-step {
            display: flex;
            flex-direction: column;
            align-items: center;
            min-width: 100px;
            position: relative;
        }
        
        .progress-step:not(:last-child)::after {
            content: '';
            position: absolute;
            top: 15px;
            right: -50%;
            width: 100%;
            height: 2px;
            background-color: var(--border-color);
            z-index: 1;
        }
        
        .progress-step.active:not(:last-child)::after {
            background-color: var(--primary-color);
        }
        
        .step-indicator {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background-color: var(--border-color);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.875rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
            position: relative;
            z-index: 2;
        }
        
        .progress-step.active .step-indicator {
            background-color: var(--primary-color);
        }
        
        .progress-step.completed .step-indicator {
            background-color: var(--success-color);
        }
        
        .step-label {
            font-size: 0.75rem;
            color: var(--text-secondary);
            text-align: center;
        }
        
        .progress-step.active .step-label {
            color: var(--primary-color);
            font-weight: 500;
        }
    </style>
</head>
<body>
    <!-- Animated Background -->
    <div class="animated-bg">
        <div class="bg-shape bg-shape-1"></div>
        <div class="bg-shape bg-shape-2"></div>
    </div>

    <div class="app-container">
        <!-- Header -->
        <header class="app-header">
            <h1 class="app-title">
                <div class="app-logo">
                    <i class="fas fa-file-medical"></i>
                </div>
                Smart Claims
            </h1>
            
            <div class="user-menu">
                <div class="user-button">
                    <div class="user-avatar">
                        <i class="fas fa-user"></i>
                    </div>
                    <span class="hidden md:inline">Admin</span>
                    <i class="fas fa-chevron-down ml-2 text-xs"></i>
                </div>
            </div>
        </header>
        
        <!-- Navigation -->
        <nav class="app-nav">
            <a href="dashboard.php" class="nav-item">
                <i class="fas fa-home"></i>
                <span>Dashboard</span>
            </a>
            <a href="patient-registration.php" class="nav-item active">
                <i class="fas fa-user-plus"></i>
                <span>Patients</span>
            </a>
            <a href="visits.php" class="nav-item">
                <i class="fas fa-clipboard-list"></i>
                <span>Visits</span>
            </a>
            <a href="vital-signs.php" class="nav-item">
                <i class="fas fa-heartbeat"></i>
                <span>Vitals</span>
            </a>
            <a href="diagnosis.php" class="nav-item">
                <i class="fas fa-stethoscope"></i>
                <span>Diagnosis</span>
            </a>
            <a href="claims.php" class="nav-item">
                <i class="fas fa-file-invoice-dollar"></i>
                <span>Claims</span>
            </a>
            <a href="settings.php" class="nav-item">
                <i class="fas fa-cog"></i>
                <span>Settings</span>
            </a>
        </nav>
        
        <!-- Page Header -->
        <div class="page-header">
            <h2 class="page-title">Patient Registration</h2>
            
            <div class="page-actions">
                <a href="dashboard.php" class="btn btn-outline">
                    <i class="fas fa-arrow-left btn-icon"></i>
                    Back to Dashboard
                </a>
            </div>
        </div>
        
        <!-- Form Progress -->
        <div class="form-progress">
            <div class="progress-step active">
                <div class="step-indicator">1</div>
                <div class="step-label">NHIS Information</div>
            </div>
            <div class="progress-step">
                <div class="step-indicator">2</div>
                <div class="step-label">Personal Details</div>
            </div>
            <div class="progress-step">
                <div class="step-indicator">3</div>
                <div class="step-label">Contact Info</div>
            </div>
            <div class="progress-step">
                <div class="step-indicator">4</div>
                <div class="step-label">Medical History</div>
            </div>
            <div class="progress-step">
                <div class="step-indicator">5</div>
                <div class="step-label">Review</div>
            </div>
        </div>
        
        <!-- Registration Form -->
        <form id="patientForm">
            <!-- NHIS Information -->
            <div class="card">
                <div class="form-section">
                    <h3 class="form-section-title">
                        <i class="fas fa-id-card"></i>
                        NHIS Information
                    </h3>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div class="form-group">
                            <label for="nhisNumber" class="form-label">NHIS Number</label>
                            <input type="text" id="nhisNumber" class="form-control" placeholder="Enter NHIS number" required>
                            <div class="form-hint">Enter the patient's NHIS identification number</div>
                        </div>
                        
                        <div class="form-group">
                            <label for="expiryDate" class="form-label">Expiry Date</label>
                            <input type="date" id="expiryDate" class="form-control">
                            <div class="form-hint">Enter the NHIS card expiry date</div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Personal Information -->
            <div class="card">
                <div class="form-section">
                    <h3 class="form-section-title">
                        <i class="fas fa-user"></i>
                        Personal Information
                    </h3>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div class="form-group">
                            <label for="firstName" class="form-label">First Name</label>
                            <input type="text" id="firstName" class="form-control" placeholder="Enter first name" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="lastName" class="form-label">Last Name</label>
                            <input type="text" id="lastName" class="form-control" placeholder="Enter last name" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="gender" class="form-label">Gender</label>
                            <select id="gender" class="form-control" required>
                                <option value="">Select gender</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="dateOfBirth" class="form-label">Date of Birth</label>
                            <input type="date" id="dateOfBirth" class="form-control" required>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Contact Information -->
            <div class="card">
                <div class="form-section">
                    <h3 class="form-section-title">
                        <i class="fas fa-address-book"></i>
                        Contact Information
                    </h3>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div class="form-group">
                            <label for="phone" class="form-label">Phone Number</label>
                            <input type="tel" id="phone" class="form-control" placeholder="Enter phone number">
                        </div>
                        
                        <div class="form-group">
                            <label for="email" class="form-label">Email Address</label>
                            <input type="email" id="email" class="form-control" placeholder="Enter email address">
                        </div>
                        
                        <div class="form-group md:col-span-2">
                            <label for="address" class="form-label">Address</label>
                            <textarea id="address" class="form-control" rows="3" placeholder="Enter address"></textarea>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Emergency Contact -->
            <div class="card">
                <div class="form-section">
                    <h3 class="form-section-title">
                        <i class="fas fa-phone-alt"></i>
                        Emergency Contact
                    </h3>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div class="form-group">
                            <label for="emergencyContact" class="form-label">Contact Name</label>
                            <input type="text" id="emergencyContact" class="form-control" placeholder="Enter emergency contact name">
                        </div>
                        
                        <div class="form-group">
                            <label for="emergencyPhone" class="form-label">Contact Phone</label>
                            <input type="tel" id="emergencyPhone" class="form-control" placeholder="Enter emergency contact phone">
                        </div>
                        
                        <div class="form-group">
                            <label for="relationship" class="form-label">Relationship</label>
                            <input type="text" id="relationship" class="form-control" placeholder="Enter relationship">
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Medical Information -->
            <div class="card">
                <div class="form-section">
                    <h3 class="form-section-title">
                        <i class="fas fa-notes-medical"></i>
                        Medical Information
                    </h3>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div class="form-group">
                            <label for="bloodGroup" class="form-label">Blood Group</label>
                            <select id="bloodGroup" class="form-control">
                                <option value="">Select blood group</option>
                                <option value="A+">A+</option>
                                <option value="A-">A-</option>
                                <option value="B+">B+</option>
                                <option value="B-">B-</option>
                                <option value="AB+">AB+</option>
                                <option value="AB-">AB-</option>
                                <option value="O+">O+</option>
                                <option value="O-">O-</option>
                            </select>
                        </div>
                        
                        <div class="form-group md:col-span-2">
                            <label for="allergies" class="form-label">Allergies</label>
                            <textarea id="allergies" class="form-control" rows="2" placeholder="Enter allergies if any"></textarea>
                        </div>
                        
                        <div class="form-group md:col-span-2">
                            <label for="medicalHistory" class="form-label">Medical History</label>
                            <textarea id="medicalHistory" class="form-control" rows="3" placeholder="Enter relevant medical history"></textarea>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Form Actions -->
            <div class="flex justify-end space-x-4 mb-8">
                <button type="reset" class="btn btn-outline">
                    <i class="fas fa-redo btn-icon"></i>
                    Clear Form
                </button>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save btn-icon"></i>
                    Register Patient
                </button>
            </div>
        </form>
    </div>
    
    <!-- Mobile Navigation -->
    <div class="mobile-nav">
        <a href="dashboard.php" class="mobile-nav-item">
            <i class="fas fa-home"></i>
            <span>Home</span>
        </a>
        <a href="patient-registration.php" class="mobile-nav-item active">
            <i class="fas fa-user-plus"></i>
            <span>Patients</span>
        </a>
        <a href="visits.php" class="mobile-nav-item">
            <i class="fas fa-clipboard-list"></i>
            <span>Visits</span>
        </a>
        <a href="claims.php" class="mobile-nav-item">
            <i class="fas fa-file-invoice-dollar"></i>
            <span>Claims</span>
        </a>
        <a href="settings.php" class="mobile-nav-item">
            <i class="fas fa-cog"></i>
            <span>Settings</span>
        </a>
    </div>
    
    <script>
        document.getElementById('patientForm').addEventListener('submit', function(e) {
            e.preventDefault();
            alert('Patient registration successful!');
            window.location.href = 'dashboard.html';
        });
    </script>
</body>
</html>