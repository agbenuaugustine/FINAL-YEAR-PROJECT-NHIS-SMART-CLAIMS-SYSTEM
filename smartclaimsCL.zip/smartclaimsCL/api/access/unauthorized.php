<?php
/**
 * Unauthorized Access Page
 * 
 * Shown when users try to access departments or functions they don't have permission for
 */

// Start session
session_start();

// Get user info if available
$user = $_SESSION['user'] ?? null;
$role = $user['role'] ?? 'guest';
$department_requested = $_GET['dept'] ?? 'unknown';

// Include department controller for navigation
require_once __DIR__ . '/department_controller.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Access Denied - Smart Claims NHIS</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #ff6b6b 0%, #ee5a24 100%);
            min-height: 100vh;
        }
    </style>
</head>
<body class="flex items-center justify-center min-h-screen p-4">
    <div class="max-w-2xl w-full">
        <div class="bg-white rounded-2xl shadow-2xl p-8 text-center">
            <!-- Error Icon -->
            <div class="flex justify-center mb-6">
                <div class="w-20 h-20 bg-red-100 rounded-full flex items-center justify-center">
                    <i class="fas fa-ban text-red-600 text-3xl"></i>
                </div>
            </div>

            <!-- Header -->
            <h1 class="text-3xl font-bold text-gray-800 mb-4">Access Denied</h1>
            <p class="text-xl text-gray-600 mb-6">You don't have permission to access this area</p>

            <!-- Details -->
            <div class="bg-red-50 border border-red-200 rounded-lg p-6 mb-6">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-left">
                    <div>
                        <h3 class="font-semibold text-red-800 mb-2">Your Role:</h3>
                        <p class="text-red-700"><?php echo ucwords(str_replace('_', ' ', $role)); ?></p>
                    </div>
                    <div>
                        <h3 class="font-semibold text-red-800 mb-2">Requested Department:</h3>
                        <p class="text-red-700"><?php echo strtoupper($department_requested); ?></p>
                    </div>
                    <div>
                        <h3 class="font-semibold text-red-800 mb-2">Your Department:</h3>
                        <p class="text-red-700"><?php echo getUserDepartment(); ?></p>
                    </div>
                    <div>
                        <h3 class="font-semibold text-red-800 mb-2">Access Level:</h3>
                        <p class="text-red-700"><?php echo isHospitalAdmin() ? 'Admin' : 'Department Staff'; ?></p>
                    </div>
                </div>
            </div>

            <!-- Available Actions -->
            <div class="mb-6">
                <h3 class="font-semibold text-gray-800 mb-4">What you can do:</h3>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <?php 
                    $navigation = getDepartmentNavigation();
                    $accessible_count = 0;
                    foreach ($navigation as $key => $nav_item):
                        if ($nav_item['accessible'] && $accessible_count < 4):
                            $accessible_count++;
                    ?>
                    <a href="<?php echo $nav_item['url']; ?>" class="bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg p-4 text-center transition-colors">
                        <i class="<?php echo $nav_item['icon']; ?> text-blue-600 text-2xl mb-2"></i>
                        <p class="font-medium text-blue-800"><?php echo $nav_item['label']; ?></p>
                    </a>
                    <?php 
                        endif;
                    endforeach; 
                    ?>
                </div>
            </div>

            <!-- Help Text -->
            <div class="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
                <h4 class="font-semibold text-yellow-800 mb-2">
                    <i class="fas fa-info-circle mr-2"></i>
                    Department Access Information
                </h4>
                <p class="text-yellow-700 text-sm">
                    Smart Claims NHIS uses role-based access control to ensure data security and workflow efficiency. 
                    Each department can only access patient data relevant to their workflow stage.
                </p>
            </div>

            <!-- Action Buttons -->
            <div class="flex justify-center space-x-4">
                <a href="dashboard.php" class="bg-blue-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-blue-700 transition-colors">
                    <i class="fas fa-tachometer-alt mr-2"></i>
                    Go to Dashboard
                </a>
                <a href="javascript:history.back()" class="bg-gray-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-gray-700 transition-colors">
                    <i class="fas fa-arrow-left mr-2"></i>
                    Go Back
                </a>
            </div>

            <!-- Footer -->
            <div class="mt-8 text-center text-sm text-gray-500">
                <p>If you believe this is an error, please contact your system administrator.</p>
            </div>
        </div>
    </div>
</body>
</html>