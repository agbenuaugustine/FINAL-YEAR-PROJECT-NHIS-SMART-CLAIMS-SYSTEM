<?php
/**
 * Reports Page
 * 
 * Performance metrics and analytics for Smart Claims NHIS system
 */

// Include secure authentication middleware
require_once __DIR__ . '/secure_auth.php';

// User data is now available from secure_auth.php
// $user and $role variables are already set
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Reports & Analytics - Smart Claims NHIS</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        /* Apple-inspired styles */
        @import url('https://fonts.googleapis.com/css2?family=SF+Pro+Display:wght@300;400;500;600;700&display=swap');
        
        :root {
            --primary-color: #0071e3;
            --secondary-color: #06c;
            --success-color: #34c759;
            --warning-color: #ff9500;
            --danger-color: #ff3b30;
            --light-bg: #f5f5f7;
            --card-bg: #ffffff;
            --text-primary: #1d1d1f;
            --text-secondary: #86868b;
            --border-color: #d2d2d7;
            
            /* NHIS Theme Colors */
            --nhis-primary: #1a5b8a;
            --nhis-secondary: #2c8fb8;
            --nhis-accent: #5cb85c;
            --nhis-gold: #f0ad4e;
            --ghana-red: #ce1126;
            --ghana-gold: #fcd116;
            --ghana-green: #006b3f;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'SF Pro Display', -apple-system, BlinkMacSystemFont, sans-serif;
        }
        
        body {
            background-color: var(--light-bg);
            color: var(--text-primary);
            line-height: 1.5;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            overflow-x: hidden;
            width: 100%;
            position: relative;
            max-width: 100vw;
        }
        
        /* App container */
        .app-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 1rem;
            overflow-x: hidden;
            width: 100%;
        }
        
        /* Header */
        .app-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 0;
            margin-bottom: 1.5rem;
        }
        
        .app-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--text-primary);
            display: flex;
            align-items: center;
        }
        
        .app-logo {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #0f2b5b, #1e88e5);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.25rem;
            transform: rotate(10deg);
            box-shadow: 0 4px 8px rgba(30, 136, 229, 0.3);
            margin-right: 0.75rem;
        }
        
        /* Navigation */
        .app-nav {
            display: flex;
            background-color: rgba(255, 255, 255, 0.8);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            margin-bottom: 1.5rem;
            overflow: hidden;
            position: sticky;
            top: 1rem;
            z-index: 100;
        }
        
        .nav-item {
            flex: 1;
            padding: 0.75rem 1rem;
            text-align: center;
            color: var(--text-secondary);
            font-weight: 500;
            transition: all 0.2s ease;
            position: relative;
            white-space: nowrap;
        }
        
        .nav-item:hover {
            color: var(--primary-color);
        }
        
        .nav-item.active {
            color: var(--primary-color);
        }
        
        .nav-item.active::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 30px;
            height: 3px;
            background-color: var(--primary-color);
            border-radius: 3px;
        }
        
        .nav-item i {
            margin-right: 0.5rem;
            font-size: 1.1rem;
        }
        
        /* Cards */
        .card {
            background-color: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border-radius: 16px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            padding: 1.75rem;
            margin-bottom: 1.75rem;
            border: 1px solid rgba(255, 255, 255, 0.2);
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }
        
        .card-title {
            font-size: 1.1rem;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 1rem;
        }
        
        /* Form Styles */
        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 1.5rem;
            margin-bottom: 1.5rem;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        .form-label {
            display: block;
            font-weight: 500;
            color: var(--text-primary);
            margin-bottom: 0.5rem;
            font-size: 0.9rem;
        }
        
        .form-control {
            width: 100%;
            padding: 0.875rem 1rem;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            font-size: 0.95rem;
            background-color: #fff;
            transition: all 0.2s ease;
        }
        
        .form-control:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(0, 113, 227, 0.1);
        }
        
        /* KPI Cards */
        .kpi-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .kpi-card {
            background: linear-gradient(135deg, rgba(255, 255, 255, 0.95), rgba(248, 250, 252, 0.95));
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-radius: 16px;
            padding: 1.5rem;
            text-align: center;
            border: 1px solid rgba(255, 255, 255, 0.2);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }
        
        .kpi-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
        }
        
        .kpi-icon {
            width: 50px;
            height: 50px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.5rem;
            margin: 0 auto 1rem;
        }
        
        .kpi-value {
            font-size: 2rem;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 0.5rem;
        }
        
        .kpi-label {
            font-size: 0.9rem;
            color: var(--text-secondary);
            margin-bottom: 0.75rem;
        }
        
        .kpi-change {
            font-size: 0.8rem;
            font-weight: 500;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .kpi-change.positive {
            color: var(--success-color);
        }
        
        .kpi-change.negative {
            color: var(--danger-color);
        }
        
        /* Chart containers */
        .chart-container {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            position: relative;
            height: 400px;
        }
        
        .chart-header {
            display: flex;
            justify-content: between;
            align-items: center;
            margin-bottom: 1rem;
        }
        
        .chart-title {
            font-size: 1.1rem;
            font-weight: 600;
            color: var(--text-primary);
        }
        
        /* Report tabs */
        .report-tabs {
            display: flex;
            background: rgba(248, 250, 252, 0.9);
            border-radius: 12px;
            padding: 0.25rem;
            margin-bottom: 1.5rem;
        }
        
        .report-tab {
            flex: 1;
            padding: 0.875rem 1.5rem;
            text-align: center;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.2s ease;
            font-weight: 500;
            color: var(--text-secondary);
        }
        
        .report-tab.active {
            background: white;
            color: var(--primary-color);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }
        
        /* Button Styles */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 0.875rem 1.5rem;
            border-radius: 8px;
            font-weight: 500;
            transition: all 0.2s ease;
            cursor: pointer;
            border: none;
            font-size: 0.95rem;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #0071e3, #42a1ec);
            color: white;
            box-shadow: 0 2px 8px rgba(0, 113, 227, 0.3);
        }
        
        .btn-primary:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(0, 113, 227, 0.4);
        }
        
        .btn-secondary {
            background: #f5f5f7;
            color: var(--text-primary);
            border: 1px solid var(--border-color);
        }
        
        .btn-success {
            background: linear-gradient(135deg, #34c759, #30d158);
            color: white;
            box-shadow: 0 2px 8px rgba(52, 199, 89, 0.3);
        }
        
        .btn-warning {
            background: linear-gradient(135deg, #ff9500, #ffcc00);
            color: white;
            box-shadow: 0 2px 8px rgba(255, 149, 0, 0.3);
        }
        
        /* Tables */
        .table-container {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-radius: 16px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            overflow-x: auto;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        .table {
            width: 100%;
            border-collapse: collapse;
            min-width: 650px;
        }
        
        .table th {
            background: rgba(248, 250, 252, 0.9);
            padding: 1rem 1.25rem;
            font-weight: 600;
            color: var(--text-primary);
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .table td {
            padding: 1rem 1.25rem;
            border-top: 1px solid rgba(0, 0, 0, 0.05);
            color: var(--text-primary);
        }
        
        /* Export options */
        .export-options {
            display: flex;
            gap: 0.5rem;
            flex-wrap: wrap;
        }
        
        .export-btn {
            padding: 0.5rem 1rem;
            border-radius: 6px;
            font-size: 0.875rem;
            font-weight: 500;
            transition: all 0.2s ease;
            cursor: pointer;
            border: 1px solid var(--border-color);
            background: white;
            color: var(--text-primary);
        }
        
        .export-btn:hover {
            background: var(--primary-color);
            color: white;
            border-color: var(--primary-color);
        }
        
        /* Mobile Navigation */
        .mobile-nav {
            display: none;
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: rgba(255, 255, 255, 0.98);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border-top: 1px solid var(--border-color);
            padding: 0.5rem 0;
            z-index: 1000;
            box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.05);
            height: 4.5rem;
            width: 100%;
            max-width: 100%;
        }

        .mobile-nav-item {
            display: inline-flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-decoration: none;
            padding: 0.4rem 0;
            color: var(--text-secondary);
            font-size: 0.65rem;
            transition: all 0.2s ease;
            width: 14.28%; /* 100% / 7 items */
            text-align: center;
            position: relative;
            overflow: hidden;
            white-space: nowrap;
        }

        .mobile-nav-item i {
            font-size: 1.25rem;
            margin-bottom: 0.25rem;
        }

        .mobile-nav-item.active {
            color: var(--primary-color);
        }
        
        .mobile-nav-item.active::after {
            content: '';
            position: absolute;
            top: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 25px;
            height: 3px;
            background-color: var(--primary-color);
            border-radius: 3px;
        }

        /* Mobile Responsive */
        @media (max-width: 768px) {
            .app-nav {
                display: none;
            }
            
            .mobile-nav {
                display: flex;
                justify-content: space-around;
            }
            
            .form-grid {
                grid-template-columns: 1fr;
                gap: 1rem;
            }
            
            .kpi-grid {
                grid-template-columns: repeat(2, 1fr);
                gap: 1rem;
            }
            
            .report-tabs {
                flex-direction: column;
                gap: 0.25rem;
            }
            
            .app-container {
                padding: 0.5rem;
                padding-bottom: 5.5rem;
            }
        }
        
        /* Animated background */
        .animated-bg {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            overflow: hidden;
        }
        
        .bg-shape {
            position: absolute;
            border-radius: 50%;
            filter: blur(70px);
            opacity: 0.3;
        }
        
        .bg-shape-1 {
            width: 500px;
            height: 500px;
            background: linear-gradient(135deg, #0071e3, #5ac8fa);
            top: -200px;
            left: -200px;
            animation: float 25s infinite ease-in-out;
        }
        
        .bg-shape-2 {
            width: 400px;
            height: 400px;
            background: linear-gradient(135deg, #5ac8fa, #007aff);
            bottom: -150px;
            right: -150px;
            animation: float 20s infinite ease-in-out reverse;
        }
        
        @keyframes float {
            0% { transform: translate(0, 0) rotate(0deg); }
            50% { transform: translate(50px, 50px) rotate(10deg); }
            100% { transform: translate(0, 0) rotate(0deg); }
        }
    </style>
</head>
<body>
    <!-- Animated Background -->
    <div class="animated-bg">
        <div class="bg-shape bg-shape-1"></div>
        <div class="bg-shape bg-shape-2"></div>
    </div>

    <div class="app-container">
        <!-- Header -->
        <header class="app-header">
            <h1 class="app-title">
                <div class="app-logo">
                    <i class="fas fa-file-medical"></i>
                </div>
                Smart Claims
            </h1>
            
            <div class="user-menu relative">
                <div class="user-button cursor-pointer" id="userMenuButton">
                    <div class="user-avatar">
                        <i class="fas fa-user"></i>
                    </div>
                    <span class="hidden md:inline"><?php echo htmlspecialchars($user['full_name'] ?? 'User'); ?></span>
                    <i class="fas fa-chevron-down ml-2 text-xs"></i>
                </div>
                <div id="userDropdown" class="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg py-2 z-50 hidden">
                    <a href="profile.php" class="block px-4 py-2 text-gray-800 hover:bg-gray-100">
                        <i class="fas fa-user-circle mr-2"></i> Profile
                    </a>
                    <a href="settings.php" class="block px-4 py-2 text-gray-800 hover:bg-gray-100">
                        <i class="fas fa-cog mr-2"></i> Settings
                    </a>
                    <div class="border-t border-gray-200 my-1"></div>
                    <a href="/smartclaimsCL/api/logout.php" class="block px-4 py-2 text-red-600 hover:bg-gray-100">
                        <i class="fas fa-sign-out-alt mr-2"></i> Logout
                    </a>
                </div>
            </div>
        </header>
        
        <!-- Navigation -->
        <nav class="app-nav">
            <a href="dashboard.php" class="nav-item">
                <i class="fas fa-tachometer-alt"></i>
                <span>Dashboard</span>
            </a>
            <a href="client-registration.php" class="nav-item">
                <i class="fas fa-user-plus"></i>
                <span>Client Registration</span>
            </a>
            <a href="service-requisition.php" class="nav-item">
                <i class="fas fa-clipboard-list"></i>
                <span>Service Requisition</span>
            </a>
            <a href="vital-signs.php" class="nav-item">
                <i class="fas fa-heartbeat"></i>
                <span>Vital Signs</span>
            </a>
            <a href="diagnosis-medication.php" class="nav-item">
                <i class="fas fa-stethoscope"></i>
                <span>Diagnosis & Medication</span>
            </a>
            <a href="claims-processing.php" class="nav-item">
                <i class="fas fa-file-invoice-dollar"></i>
                <span>Claims Processing</span>
            </a>
            <a href="reports.php" class="nav-item active">
                <i class="fas fa-chart-bar"></i>
                <span>Reports</span>
            </a>
        </nav>
        
        <!-- Main Content -->
        <main>
            <!-- Page Header -->
            <div class="card">
                <div class="flex justify-between items-center">
                    <div>
                        <h2 class="card-title text-2xl font-bold mb-2">
                            <i class="fas fa-chart-bar mr-2"></i>
                            Reports & Analytics
                        </h2>
                        <p class="text-secondary text-lg">Performance metrics and insights for Smart Claims NHIS system</p>
                        <p class="text-sm text-gray-600 mt-2">Real-time analytics and comprehensive reporting</p>
                    </div>
                    <div class="flex space-x-2">
                        <button class="btn btn-secondary" onclick="refreshData()">
                            <i class="fas fa-sync mr-2"></i>
                            Refresh Data
                        </button>
                        <button class="btn btn-warning" onclick="scheduleReport()">
                            <i class="fas fa-clock mr-2"></i>
                            Schedule Report
                        </button>
                    </div>
                </div>
            </div>

            <!-- Report Filters -->
            <div class="card">
                <h3 class="card-title text-xl font-bold mb-4">
                    <i class="fas fa-filter mr-2"></i>
                    Report Filters
                </h3>
                
                <div class="form-grid">
                    <div class="form-group">
                        <label for="date_range" class="form-label">Date Range</label>
                        <select id="date_range" class="form-control" onchange="updateDateRange()">
                            <option value="today">Today</option>
                            <option value="week">This Week</option>
                            <option value="month" selected>This Month</option>
                            <option value="quarter">This Quarter</option>
                            <option value="year">This Year</option>
                            <option value="custom">Custom Range</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="department" class="form-label">Department</label>
                        <select id="department" class="form-control" onchange="updateCharts()">
                            <option value="">All Departments</option>
                            <option value="opd">OPD</option>
                            <option value="laboratory">Laboratory</option>
                            <option value="pharmacy">Pharmacy</option>
                            <option value="emergency">Emergency</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="physician" class="form-label">Physician</label>
                        <select id="physician" class="form-control" onchange="updateCharts()">
                            <option value="">All Physicians</option>
                            <option value="dr_asante">Dr. Kwame Asante</option>
                            <option value="dr_mensah">Dr. Grace Mensah</option>
                            <option value="dr_osei">Dr. John Osei</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="claim_status" class="form-label">Claim Status</label>
                        <select id="claim_status" class="form-control" onchange="updateCharts()">
                            <option value="">All Statuses</option>
                            <option value="submitted">Submitted</option>
                            <option value="approved">Approved</option>
                            <option value="rejected">Rejected</option>
                            <option value="paid">Paid</option>
                        </select>
                    </div>
                </div>
                
                <div class="flex justify-between items-center mt-4">
                    <div class="text-sm text-gray-600">
                        <i class="fas fa-info-circle mr-1"></i>
                        Reports are updated in real-time
                    </div>
                    <div class="export-options">
                        <button class="export-btn" onclick="exportReport('pdf')">
                            <i class="fas fa-file-pdf mr-1"></i> PDF
                        </button>
                        <button class="export-btn" onclick="exportReport('excel')">
                            <i class="fas fa-file-excel mr-1"></i> Excel
                        </button>
                        <button class="export-btn" onclick="exportReport('csv')">
                            <i class="fas fa-file-csv mr-1"></i> CSV
                        </button>
                    </div>
                </div>
            </div>

            <!-- Key Performance Indicators -->
            <div class="card">
                <h3 class="card-title text-xl font-bold mb-4">
                    <i class="fas fa-tachometer-alt mr-2"></i>
                    Key Performance Indicators
                </h3>
                
                <div class="kpi-grid">
                    <div class="kpi-card">
                        <div class="kpi-icon" style="background: linear-gradient(135deg, #0071e3, #42a1ec);">
                            <i class="fas fa-users"></i>
                        </div>
                        <div class="kpi-value">1,247</div>
                        <div class="kpi-label">Total Clients Registered</div>
                        <div class="kpi-change positive">
                            <i class="fas fa-arrow-up mr-1"></i>
                            12% vs last month
                        </div>
                    </div>
                    
                    <div class="kpi-card">
                        <div class="kpi-icon" style="background: linear-gradient(135deg, #34c759, #30d158);">
                            <i class="fas fa-file-medical"></i>
                        </div>
                        <div class="kpi-value">856</div>
                        <div class="kpi-label">Claims Processed</div>
                        <div class="kpi-change positive">
                            <i class="fas fa-arrow-up mr-1"></i>
                            18% improvement
                        </div>
                    </div>
                    
                    <div class="kpi-card">
                        <div class="kpi-icon" style="background: linear-gradient(135deg, #ff9500, #ffcc00);">
                            <i class="fas fa-percentage"></i>
                        </div>
                        <div class="kpi-value">94.3%</div>
                        <div class="kpi-label">Approval Rate</div>
                        <div class="kpi-change positive">
                            <i class="fas fa-arrow-up mr-1"></i>
                            3.2% increase
                        </div>
                    </div>
                    
                    <div class="kpi-card">
                        <div class="kpi-icon" style="background: linear-gradient(135deg, #af52de, #bf5af2);">
                            <i class="fas fa-clock"></i>
                        </div>
                        <div class="kpi-value">4.2 hrs</div>
                        <div class="kpi-label">Avg. Processing Time</div>
                        <div class="kpi-change positive">
                            <i class="fas fa-arrow-down mr-1"></i>
                            2.1 hrs faster
                        </div>
                    </div>
                    
                    <div class="kpi-card">
                        <div class="kpi-icon" style="background: linear-gradient(135deg, #007aff, #5ac8fa);">
                            <i class="fas fa-money-bill-wave"></i>
                        </div>
                        <div class="kpi-value">₵142,580</div>
                        <div class="kpi-label">Total Reimbursements</div>
                        <div class="kpi-change positive">
                            <i class="fas fa-arrow-up mr-1"></i>
                            ₵15,240 increase
                        </div>
                    </div>
                    
                    <div class="kpi-card">
                        <div class="kpi-icon" style="background: linear-gradient(135deg, #ff3b30, #ff6b6b);">
                            <i class="fas fa-chart-line"></i>
                        </div>
                        <div class="kpi-value">89%</div>
                        <div class="kpi-label">System Efficiency</div>
                        <div class="kpi-change positive">
                            <i class="fas fa-arrow-up mr-1"></i>
                            7% improvement
                        </div>
                    </div>
                </div>
            </div>

            <!-- Report Categories -->
            <div class="card">
                <h3 class="card-title text-xl font-bold mb-4">
                    <i class="fas fa-folder-open mr-2"></i>
                    Report Categories
                </h3>
                
                <div class="report-tabs">
                    <div class="report-tab active" data-tab="overview" onclick="switchTab('overview')">
                        <i class="fas fa-chart-pie mr-2"></i>
                        Overview
                    </div>
                    <div class="report-tab" data-tab="claims" onclick="switchTab('claims')">
                        <i class="fas fa-file-invoice mr-2"></i>
                        Claims Analysis
                    </div>
                    <div class="report-tab" data-tab="financial" onclick="switchTab('financial')">
                        <i class="fas fa-dollar-sign mr-2"></i>
                        Financial
                    </div>
                    <div class="report-tab" data-tab="operational" onclick="switchTab('operational')">
                        <i class="fas fa-cogs mr-2"></i>
                        Operational
                    </div>
                </div>

                <!-- Overview Tab -->
                <div id="overview-tab" class="tab-content">
                    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        <!-- Claims Trend Chart -->
                        <div class="chart-container">
                            <div class="chart-header">
                                <h4 class="chart-title">Claims Trend (Last 6 Months)</h4>
                            </div>
                            <canvas id="claimsTrendChart"></canvas>
                        </div>
                        
                        <!-- Department Performance -->
                        <div class="chart-container">
                            <div class="chart-header">
                                <h4 class="chart-title">Department Performance</h4>
                            </div>
                            <canvas id="departmentChart"></canvas>
                        </div>
                        
                        <!-- Status Distribution -->
                        <div class="chart-container">
                            <div class="chart-header">
                                <h4 class="chart-title">Claims Status Distribution</h4>
                            </div>
                            <canvas id="statusChart"></canvas>
                        </div>
                        
                        <!-- Processing Time Trend -->
                        <div class="chart-container">
                            <div class="chart-header">
                                <h4 class="chart-title">Processing Time Improvement</h4>
                            </div>
                            <canvas id="processingTimeChart"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Claims Analysis Tab -->
                <div id="claims-tab" class="tab-content hidden">
                    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        <!-- Top Diagnoses -->
                        <div class="chart-container">
                            <div class="chart-header">
                                <h4 class="chart-title">Top 10 Diagnoses</h4>
                            </div>
                            <canvas id="diagnosisChart"></canvas>
                        </div>
                        
                        <!-- Approval Rates by Department -->
                        <div class="chart-container">
                            <div class="chart-header">
                                <h4 class="chart-title">Approval Rates by Department</h4>
                            </div>
                            <canvas id="approvalRatesChart"></canvas>
                        </div>
                        
                        <!-- Claims by Age Group -->
                        <div class="chart-container">
                            <div class="chart-header">
                                <h4 class="chart-title">Claims by Patient Age Group</h4>
                            </div>
                            <canvas id="ageGroupChart"></canvas>
                        </div>
                        
                        <!-- Rejection Reasons -->
                        <div class="chart-container">
                            <div class="chart-header">
                                <h4 class="chart-title">Common Rejection Reasons</h4>
                            </div>
                            <canvas id="rejectionChart"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Financial Tab -->
                <div id="financial-tab" class="tab-content hidden">
                    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        <!-- Revenue Trend -->
                        <div class="chart-container">
                            <div class="chart-header">
                                <h4 class="chart-title">Monthly Revenue Trend</h4>
                            </div>
                            <canvas id="revenueChart"></canvas>
                        </div>
                        
                        <!-- Cost Savings -->
                        <div class="chart-container">
                            <div class="chart-header">
                                <h4 class="chart-title">Cost Savings from Automation</h4>
                            </div>
                            <canvas id="costSavingsChart"></canvas>
                        </div>
                        
                        <!-- Reimbursement Timeline -->
                        <div class="chart-container">
                            <div class="chart-header">
                                <h4 class="chart-title">Average Reimbursement Timeline</h4>
                            </div>
                            <canvas id="reimbursementChart"></canvas>
                        </div>
                        
                        <!-- Top Revenue Generators -->
                        <div class="chart-container">
                            <div class="chart-header">
                                <h4 class="chart-title">Top Revenue Generating Services</h4>
                            </div>
                            <canvas id="revenueServicesChart"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Operational Tab -->
                <div id="operational-tab" class="tab-content hidden">
                    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        <!-- System Usage -->
                        <div class="chart-container">
                            <div class="chart-header">
                                <h4 class="chart-title">Daily System Usage</h4>
                            </div>
                            <canvas id="usageChart"></canvas>
                        </div>
                        
                        <!-- User Performance -->
                        <div class="chart-container">
                            <div class="chart-header">
                                <h4 class="chart-title">User Performance Metrics</h4>
                            </div>
                            <canvas id="userPerformanceChart"></canvas>
                        </div>
                        
                        <!-- Error Rates -->
                        <div class="chart-container">
                            <div class="chart-header">
                                <h4 class="chart-title">Error Rate Reduction</h4>
                            </div>
                            <canvas id="errorRateChart"></canvas>
                        </div>
                        
                        <!-- Compliance Score -->
                        <div class="chart-container">
                            <div class="chart-header">
                                <h4 class="chart-title">NHIA Compliance Score</h4>
                            </div>
                            <canvas id="complianceChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Detailed Reports Table -->
            <div class="card">
                <h3 class="card-title text-xl font-bold mb-4">
                    <i class="fas fa-table mr-2"></i>
                    Detailed Claims Report
                </h3>
                <div class="table-container">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Patient</th>
                                <th>NHIS Number</th>
                                <th>Diagnosis</th>
                                <th>Department</th>
                                <th>Amount</th>
                                <th>Status</th>
                                <th>Processing Time</th>
                            </tr>
                        </thead>
                        <tbody id="detailedReportsTable">
                            <tr>
                                <td colspan="8" class="text-center py-4">Loading detailed reports...</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Smart Insights -->
            <div class="card">
                <h3 class="card-title text-xl font-bold mb-4">
                    <i class="fas fa-lightbulb mr-2"></i>
                    Smart Insights & Recommendations
                </h3>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                        <div class="flex items-center mb-2">
                            <i class="fas fa-trending-up text-blue-600 mr-2"></i>
                            <strong class="text-blue-800">Performance Improvement</strong>
                        </div>
                        <p class="text-blue-700 text-sm">Claims processing time has improved by 65% since implementing Smart Claims. Consider expanding to other departments.</p>
                    </div>
                    
                    <div class="p-4 bg-green-50 border border-green-200 rounded-lg">
                        <div class="flex items-center mb-2">
                            <i class="fas fa-check-circle text-green-600 mr-2"></i>
                            <strong class="text-green-800">High Approval Rate</strong>
                        </div>
                        <p class="text-green-700 text-sm">94.3% approval rate indicates excellent compliance with NHIA standards. Maintain current quality processes.</p>
                    </div>
                    
                    <div class="p-4 bg-orange-50 border border-orange-200 rounded-lg">
                        <div class="flex items-center mb-2">
                            <i class="fas fa-exclamation-triangle text-orange-600 mr-2"></i>
                            <strong class="text-orange-800">Peak Hour Analysis</strong>
                        </div>
                        <p class="text-orange-700 text-sm">Consider additional staff during 10-12 PM peak hours to reduce patient waiting time.</p>
                    </div>
                    
                    <div class="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                        <div class="flex items-center mb-2">
                            <i class="fas fa-dollar-sign text-purple-600 mr-2"></i>
                            <strong class="text-purple-800">Cost Optimization</strong>
                        </div>
                        <p class="text-purple-700 text-sm">Automated tariff calculation has reduced billing errors by 87%, saving ₵12,500 monthly in corrections.</p>
                    </div>
                </div>
            </div>
        </main>
        
        <!-- Mobile Navigation -->
        <div class="mobile-nav">
            <a href="dashboard.php" class="mobile-nav-item">
                <i class="fas fa-tachometer-alt"></i>
                <span>Dashboard</span>
            </a>
            <a href="client-registration.php" class="mobile-nav-item">
                <i class="fas fa-user-plus"></i>
                <span>Clients</span>
            </a>
            <a href="service-requisition.php" class="mobile-nav-item">
                <i class="fas fa-clipboard-list"></i>
                <span>Services</span>
            </a>
            <a href="vital-signs.php" class="mobile-nav-item">
                <i class="fas fa-heartbeat"></i>
                <span>Vitals</span>
            </a>
            <a href="diagnosis-medication.php" class="mobile-nav-item">
                <i class="fas fa-stethoscope"></i>
                <span>Diagnosis</span>
            </a>
            <a href="claims-processing.php" class="mobile-nav-item">
                <i class="fas fa-file-invoice-dollar"></i>
                <span>Claims</span>
            </a>
            <a href="reports.php" class="mobile-nav-item active">
                <i class="fas fa-chart-bar"></i>
                <span>Reports</span>
            </a>
        </div>
    </div>

    <script>
        let charts = {};
        
        document.addEventListener('DOMContentLoaded', function() {
            // Initialize the page
            initializePage();
            initializeCharts();
            loadDetailedReports();
        });

        // Initialize page
        function initializePage() {
            // Setup user dropdown
            const userMenuButton = document.getElementById('userMenuButton');
            const userDropdown = document.getElementById('userDropdown');
            
            userMenuButton.addEventListener('click', function(e) {
                e.stopPropagation();
                userDropdown.classList.toggle('hidden');
            });
            
            document.addEventListener('click', function(e) {
                if (!userMenuButton.contains(e.target) && !userDropdown.contains(e.target)) {
                    userDropdown.classList.add('hidden');
                }
            });
        }

        // Initialize all charts
        function initializeCharts() {
            initializeClaimsTrendChart();
            initializeDepartmentChart();
            initializeStatusChart();
            initializeProcessingTimeChart();
            // Initialize other charts when their tabs are accessed
        }

        // Claims Trend Chart
        function initializeClaimsTrendChart() {
            const ctx = document.getElementById('claimsTrendChart').getContext('2d');
            charts.claimsTrend = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: ['Aug', 'Sep', 'Oct', 'Nov', 'Dec', 'Jan'],
                    datasets: [{
                        label: 'Total Claims',
                        data: [120, 145, 180, 210, 245, 280],
                        borderColor: '#0071e3',
                        backgroundColor: 'rgba(0, 113, 227, 0.1)',
                        fill: true,
                        tension: 0.4
                    }, {
                        label: 'Approved Claims',
                        data: [110, 135, 168, 195, 228, 265],
                        borderColor: '#34c759',
                        backgroundColor: 'rgba(52, 199, 89, 0.1)',
                        fill: true,
                        tension: 0.4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'top',
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        }

        // Department Performance Chart
        function initializeDepartmentChart() {
            const ctx = document.getElementById('departmentChart').getContext('2d');
            charts.department = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: ['OPD', 'Laboratory', 'Pharmacy', 'Emergency'],
                    datasets: [{
                        label: 'Claims Processed',
                        data: [145, 89, 67, 23],
                        backgroundColor: [
                            'rgba(0, 113, 227, 0.8)',
                            'rgba(52, 199, 89, 0.8)',
                            'rgba(255, 149, 0, 0.8)',
                            'rgba(255, 59, 48, 0.8)'
                        ],
                        borderColor: [
                            '#0071e3',
                            '#34c759',
                            '#ff9500',
                            '#ff3b30'
                        ],
                        borderWidth: 2
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        }

        // Status Distribution Chart
        function initializeStatusChart() {
            const ctx = document.getElementById('statusChart').getContext('2d');
            charts.status = new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: ['Approved', 'Processing', 'Rejected', 'Paid'],
                    datasets: [{
                        data: [65, 20, 8, 7],
                        backgroundColor: [
                            '#34c759',
                            '#ff9500',
                            '#ff3b30',
                            '#007aff'
                        ],
                        borderWidth: 2,
                        borderColor: '#fff'
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom',
                        }
                    }
                }
            });
        }

        // Processing Time Chart
        function initializeProcessingTimeChart() {
            const ctx = document.getElementById('processingTimeChart').getContext('2d');
            charts.processingTime = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
                    datasets: [{
                        label: 'Processing Time (hours)',
                        data: [12.5, 8.2, 6.1, 4.2],
                        borderColor: '#ff9500',
                        backgroundColor: 'rgba(255, 149, 0, 0.1)',
                        fill: true,
                        tension: 0.4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            title: {
                                display: true,
                                text: 'Hours'
                            }
                        }
                    }
                }
            });
        }

        // Switch between report tabs
        function switchTab(tabName) {
            // Update tab buttons
            document.querySelectorAll('.report-tab').forEach(tab => {
                tab.classList.remove('active');
            });
            document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
            
            // Update tab content
            document.querySelectorAll('.tab-content').forEach(content => {
                content.classList.add('hidden');
            });
            document.getElementById(`${tabName}-tab`).classList.remove('hidden');
            
            // Initialize charts for the active tab if not already done
            if (tabName === 'claims' && !charts.diagnosis) {
                initializeClaimsCharts();
            } else if (tabName === 'financial' && !charts.revenue) {
                initializeFinancialCharts();
            } else if (tabName === 'operational' && !charts.usage) {
                initializeOperationalCharts();
            }
        }

        // Initialize Claims Analysis charts
        function initializeClaimsCharts() {
            // Top Diagnoses Chart
            const diagnosisCtx = document.getElementById('diagnosisChart').getContext('2d');
            charts.diagnosis = new Chart(diagnosisCtx, {
                type: 'horizontalBar',
                data: {
                    labels: ['Upper Respiratory Infection', 'Malaria', 'Hypertension', 'Diabetes', 'Gastroenteritis'],
                    datasets: [{
                        label: 'Number of Cases',
                        data: [45, 38, 32, 28, 24],
                        backgroundColor: 'rgba(0, 113, 227, 0.8)',
                        borderColor: '#0071e3',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    }
                }
            });
            
            // Other claims charts would be initialized here
        }

        // Initialize Financial charts
        function initializeFinancialCharts() {
            // Revenue Chart
            const revenueCtx = document.getElementById('revenueChart').getContext('2d');
            charts.revenue = new Chart(revenueCtx, {
                type: 'bar',
                data: {
                    labels: ['Aug', 'Sep', 'Oct', 'Nov', 'Dec', 'Jan'],
                    datasets: [{
                        label: 'Revenue (₵)',
                        data: [45000, 52000, 58000, 61000, 67000, 72000],
                        backgroundColor: 'rgba(52, 199, 89, 0.8)',
                        borderColor: '#34c759',
                        borderWidth: 2
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
            
            // Other financial charts would be initialized here
        }

        // Initialize Operational charts
        function initializeOperationalCharts() {
            // System Usage Chart
            const usageCtx = document.getElementById('usageChart').getContext('2d');
            charts.usage = new Chart(usageCtx, {
                type: 'line',
                data: {
                    labels: ['6 AM', '8 AM', '10 AM', '12 PM', '2 PM', '4 PM', '6 PM'],
                    datasets: [{
                        label: 'Active Users',
                        data: [5, 12, 25, 35, 28, 22, 8],
                        borderColor: '#007aff',
                        backgroundColor: 'rgba(0, 122, 255, 0.1)',
                        fill: true,
                        tension: 0.4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
            
            // Other operational charts would be initialized here
        }

        // Update charts based on filters
        function updateCharts() {
            const department = document.getElementById('department').value;
            const physician = document.getElementById('physician').value;
            const claimStatus = document.getElementById('claim_status').value;
            
            // Simulate data update based on filters
            console.log('Updating charts with filters:', { department, physician, claimStatus });
            
            // In a real implementation, you would fetch new data and update charts
            showAlert('Charts updated based on selected filters', 'success');
        }

        // Update date range
        function updateDateRange() {
            const dateRange = document.getElementById('date_range').value;
            
            if (dateRange === 'custom') {
                // Show custom date picker
                const startDate = prompt('Enter start date (YYYY-MM-DD):');
                const endDate = prompt('Enter end date (YYYY-MM-DD):');
                
                if (startDate && endDate) {
                    showAlert(`Custom date range selected: ${startDate} to ${endDate}`, 'info');
                    updateCharts();
                }
            } else {
                showAlert(`Date range updated to: ${dateRange}`, 'info');
                updateCharts();
            }
        }

        // Load detailed reports
        function loadDetailedReports() {
            const tableBody = document.getElementById('detailedReportsTable');
            
            // Mock detailed reports data
            const mockReports = [
                {
                    date: '2024-01-15',
                    patient: 'Grace Mensah',
                    nhis: '1234567890',
                    diagnosis: 'J06.9 - Upper respiratory infection',
                    department: 'OPD',
                    amount: '₵145.00',
                    status: 'Approved',
                    processingTime: '3.2 hrs'
                },
                {
                    date: '2024-01-15',
                    patient: 'John Asante',
                    nhis: '0987654321',
                    diagnosis: 'B50.9 - Malaria',
                    department: 'Emergency',
                    amount: '₵280.50',
                    status: 'Processing',
                    processingTime: '1.5 hrs'
                },
                {
                    date: '2024-01-14',
                    patient: 'Mary Osei',
                    nhis: '5432167890',
                    diagnosis: 'I10 - Hypertension',
                    department: 'OPD',
                    amount: '₵95.00',
                    status: 'Paid',
                    processingTime: '4.8 hrs'
                }
            ];
            
            tableBody.innerHTML = '';
            
            mockReports.forEach(report => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${report.date}</td>
                    <td>${report.patient}</td>
                    <td>${report.nhis}</td>
                    <td>${report.diagnosis}</td>
                    <td>${report.department}</td>
                    <td>${report.amount}</td>
                    <td>
                        <span class="px-2 py-1 text-xs rounded-full ${getStatusClass(report.status)}">
                            ${report.status}
                        </span>
                    </td>
                    <td>${report.processingTime}</td>
                `;
                tableBody.appendChild(row);
            });
        }

        // Get status class for styling
        function getStatusClass(status) {
            switch(status.toLowerCase()) {
                case 'approved': return 'bg-green-100 text-green-800';
                case 'processing': return 'bg-yellow-100 text-yellow-800';
                case 'rejected': return 'bg-red-100 text-red-800';
                case 'paid': return 'bg-blue-100 text-blue-800';
                default: return 'bg-gray-100 text-gray-800';
            }
        }

        // Export report
        function exportReport(format) {
            showAlert(`Exporting report in ${format.toUpperCase()} format...`, 'info');
            
            setTimeout(() => {
                showAlert(`Report exported successfully as ${format.toUpperCase()}!`, 'success');
                // In a real implementation, this would trigger the actual download
            }, 2000);
        }

        // Refresh data
        function refreshData() {
            showAlert('Refreshing all reports data...', 'info');
            
            setTimeout(() => {
                // Simulate data refresh
                updateCharts();
                loadDetailedReports();
                showAlert('All data refreshed successfully!', 'success');
            }, 2000);
        }

        // Schedule report
        function scheduleReport() {
            const schedule = prompt('Schedule report generation:\n1. Daily\n2. Weekly\n3. Monthly\n\nEnter choice (1-3):');
            
            if (schedule) {
                const scheduleTypes = ['', 'Daily', 'Weekly', 'Monthly'];
                const selectedSchedule = scheduleTypes[parseInt(schedule)];
                
                if (selectedSchedule) {
                    showAlert(`Report scheduled for ${selectedSchedule} generation`, 'success');
                } else {
                    showAlert('Invalid selection', 'warning');
                }
            }
        }

        // Show alert message
        function showAlert(message, type) {
            // Create alert element
            const alertDiv = document.createElement('div');
            alertDiv.className = `fixed top-4 right-4 px-4 py-2 rounded-lg shadow-lg z-50 ${getAlertClass(type)}`;
            alertDiv.innerHTML = `
                <i class="fas fa-${getAlertIcon(type)} mr-2"></i>
                ${message}
            `;
            
            document.body.appendChild(alertDiv);
            
            // Auto-remove after 3 seconds
            setTimeout(() => {
                alertDiv.remove();
            }, 3000);
        }

        function getAlertClass(type) {
            switch(type) {
                case 'success': return 'bg-green-500 text-white';
                case 'warning': return 'bg-yellow-500 text-white';
                case 'danger': return 'bg-red-500 text-white';
                case 'info': return 'bg-blue-500 text-white';
                default: return 'bg-gray-500 text-white';
            }
        }

        function getAlertIcon(type) {
            switch(type) {
                case 'success': return 'check-circle';
                case 'warning': return 'exclamation-triangle';
                case 'danger': return 'exclamation-circle';
                case 'info': return 'info-circle';
                default: return 'bell';
            }
        }
    </script>
</body>
</html>