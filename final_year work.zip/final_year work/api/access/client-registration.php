<?php
/**
 * Client Registration Page
 * 
 * NHIS client registration with demographics and NHIS details
 */

// Include secure authentication middleware
require_once __DIR__ . '/secure_auth.php';

// User data is now available from secure_auth.php
// $user and $role variables are already set
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Client Registration - Smart Claims NHIS</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* Apple-inspired styles */
        @import url('https://fonts.googleapis.com/css2?family=SF+Pro+Display:wght@300;400;500;600;700&display=swap');
        
        :root {
            --primary-color: #0071e3;
            --secondary-color: #06c;
            --success-color: #34c759;
            --warning-color: #ff9500;
            --danger-color: #ff3b30;
            --light-bg: #f5f5f7;
            --card-bg: #ffffff;
            --text-primary: #1d1d1f;
            --text-secondary: #86868b;
            --border-color: #d2d2d7;
            
            /* NHIS Theme Colors */
            --nhis-primary: #1a5b8a;
            --nhis-secondary: #2c8fb8;
            --nhis-accent: #5cb85c;
            --nhis-gold: #f0ad4e;
            --ghana-red: #ce1126;
            --ghana-gold: #fcd116;
            --ghana-green: #006b3f;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'SF Pro Display', -apple-system, BlinkMacSystemFont, sans-serif;
        }
        
        body {
            background-color: var(--light-bg);
            color: var(--text-primary);
            line-height: 1.5;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            overflow-x: hidden;
            width: 100%;
            position: relative;
            max-width: 100vw;
        }
        
        /* App container */
        .app-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 1rem;
            overflow-x: hidden;
            width: 100%;
        }
        
        /* Header */
        .app-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 0;
            margin-bottom: 1.5rem;
        }
        
        .app-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--text-primary);
            display: flex;
            align-items: center;
        }
        
        .app-logo {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #0f2b5b, #1e88e5);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.25rem;
            transform: rotate(10deg);
            box-shadow: 0 4px 8px rgba(30, 136, 229, 0.3);
            margin-right: 0.75rem;
        }
        
        /* Navigation */
        .app-nav {
            display: flex;
            background-color: rgba(255, 255, 255, 0.8);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            margin-bottom: 1.5rem;
            overflow: hidden;
            position: sticky;
            top: 1rem;
            z-index: 100;
        }
        
        .nav-item {
            flex: 1;
            padding: 0.75rem 1rem;
            text-align: center;
            color: var(--text-secondary);
            font-weight: 500;
            transition: all 0.2s ease;
            position: relative;
            white-space: nowrap;
        }
        
        .nav-item:hover {
            color: var(--primary-color);
        }
        
        .nav-item.active {
            color: var(--primary-color);
        }
        
        .nav-item.active::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 30px;
            height: 3px;
            background-color: var(--primary-color);
            border-radius: 3px;
        }
        
        .nav-item i {
            margin-right: 0.5rem;
            font-size: 1.1rem;
        }
        
        /* Cards */
        .card {
            background-color: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border-radius: 16px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            padding: 1.75rem;
            margin-bottom: 1.75rem;
            border: 1px solid rgba(255, 255, 255, 0.2);
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }
        
        .card-title {
            font-size: 1.1rem;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 1rem;
        }
        
        /* Form Styles */
        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 1.5rem;
            margin-bottom: 1.5rem;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        .form-label {
            display: block;
            font-weight: 500;
            color: var(--text-primary);
            margin-bottom: 0.5rem;
            font-size: 0.9rem;
        }
        
        .form-control {
            width: 100%;
            padding: 0.875rem 1rem;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            font-size: 0.95rem;
            background-color: #fff;
            transition: all 0.2s ease;
        }
        
        .form-control:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(0, 113, 227, 0.1);
        }
        
        .form-control:required {
            border-left: 3px solid var(--warning-color);
        }
        
        .form-control:valid {
            border-left: 3px solid var(--success-color);
        }
        
        /* Button Styles */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 0.875rem 1.5rem;
            border-radius: 8px;
            font-weight: 500;
            transition: all 0.2s ease;
            cursor: pointer;
            border: none;
            font-size: 0.95rem;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #0071e3, #42a1ec);
            color: white;
            box-shadow: 0 2px 8px rgba(0, 113, 227, 0.3);
        }
        
        .btn-primary:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(0, 113, 227, 0.4);
        }
        
        .btn-secondary {
            background: #f5f5f7;
            color: var(--text-primary);
            border: 1px solid var(--border-color);
        }
        
        .btn-secondary:hover {
            background: #e8e8ed;
        }
        
        .btn-success {
            background: linear-gradient(135deg, #34c759, #30d158);
            color: white;
            box-shadow: 0 2px 8px rgba(52, 199, 89, 0.3);
        }
        
        .btn-info {
            background: linear-gradient(135deg, #17a2b8, #138496);
            color: white;
            box-shadow: 0 2px 8px rgba(23, 162, 184, 0.3);
        }
        
        .btn-info:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(23, 162, 184, 0.4);
        }
        
        /* Alert Styles */
        .alert {
            padding: 1rem 1.25rem;
            border-radius: 8px;
            margin-bottom: 1rem;
            border-left: 4px solid;
        }
        
        .alert-success {
            background: #d4edda;
            color: #155724;
            border-left-color: #28a745;
        }
        
        .alert-warning {
            background: #fff3cd;
            color: #856404;
            border-left-color: #ffc107;
        }
        
        .alert-danger {
            background: #f8d7da;
            color: #721c24;
            border-left-color: #dc3545;
        }
        
        /* NHIS Card Styles */
        .nhis-status {
            display: inline-flex;
            align-items: center;
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
            margin-top: 0.5rem;
        }
        
        .nhis-active {
            background: linear-gradient(135deg, #d4edda, #c3e6cb);
            color: #155724;
        }
        
        .nhis-expired {
            background: linear-gradient(135deg, #f8d7da, #f5c6cb);
            color: #721c24;
        }
        
        .nhis-pending {
            background: linear-gradient(135deg, #fff3cd, #ffeeba);
            color: #856404;
        }
        
        /* Mobile Navigation */
        .mobile-nav {
            display: none;
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: rgba(255, 255, 255, 0.98);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border-top: 1px solid var(--border-color);
            padding: 0.5rem 0;
            z-index: 1000;
            box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.05);
            height: 4.5rem;
            width: 100%;
            max-width: 100%;
        }

        .mobile-nav-item {
            display: inline-flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-decoration: none;
            padding: 0.4rem 0;
            color: var(--text-secondary);
            font-size: 0.65rem;
            transition: all 0.2s ease;
            width: 14.28%; /* 100% / 7 items */
            text-align: center;
            position: relative;
            overflow: hidden;
            white-space: nowrap;
        }

        .mobile-nav-item i {
            font-size: 1.25rem;
            margin-bottom: 0.25rem;
        }

        .mobile-nav-item.active {
            color: var(--primary-color);
        }
        
        .mobile-nav-item.active::after {
            content: '';
            position: absolute;
            top: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 25px;
            height: 3px;
            background-color: var(--primary-color);
            border-radius: 3px;
        }

        /* Mobile Responsive */
        @media (max-width: 768px) {
            .app-nav {
                display: none;
            }
            
            .mobile-nav {
                display: flex;
                justify-content: space-around;
            }
            
            .form-grid {
                grid-template-columns: 1fr;
                gap: 1rem;
            }
            
            .app-container {
                padding: 0.5rem;
                padding-bottom: 5.5rem;
            }
        }
        
        /* Animated background */
        .animated-bg {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            overflow: hidden;
        }
        
        .bg-shape {
            position: absolute;
            border-radius: 50%;
            filter: blur(70px);
            opacity: 0.3;
        }
        
        .bg-shape-1 {
            width: 500px;
            height: 500px;
            background: linear-gradient(135deg, #0071e3, #5ac8fa);
            top: -200px;
            left: -200px;
            animation: float 25s infinite ease-in-out;
        }
        
        .bg-shape-2 {
            width: 400px;
            height: 400px;
            background: linear-gradient(135deg, #5ac8fa, #007aff);
            bottom: -150px;
            right: -150px;
            animation: float 20s infinite ease-in-out reverse;
        }
        
        @keyframes float {
            0% { transform: translate(0, 0) rotate(0deg); }
            50% { transform: translate(50px, 50px) rotate(10deg); }
            100% { transform: translate(0, 0) rotate(0deg); }
        }
        
        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(8px);
        }
        
        .modal.show {
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .modal-content {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-radius: 20px;
            padding: 0;
            max-width: 95%;
            max-height: 90%;
            width: 1200px;
            box-shadow: 0 25px 50px rgba(0, 0, 0, 0.25);
            border: 1px solid rgba(255, 255, 255, 0.2);
            overflow: hidden;
            animation: modalSlideIn 0.3s ease-out;
        }
        
        .modal-header {
            padding: 1.5rem 2rem;
            border-bottom: 1px solid var(--border-color);
            background: linear-gradient(135deg, var(--nhis-primary), var(--nhis-secondary));
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .modal-title {
            font-size: 1.5rem;
            font-weight: bold;
            margin: 0;
        }
        
        .modal-close {
            background: none;
            border: none;
            color: white;
            font-size: 1.5rem;
            cursor: pointer;
            padding: 0.5rem;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s;
        }
        
        .modal-close:hover {
            background: rgba(255, 255, 255, 0.2);
        }
        
        .modal-body {
            padding: 1.5rem 2rem;
            max-height: 60vh;
            overflow-y: auto;
        }
        
        .clients-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
        }
        
        .clients-table th,
        .clients-table td {
            padding: 0.75rem;
            text-align: left;
            border-bottom: 1px solid var(--border-color);
        }
        
        .clients-table th {
            background: #f8f9fa;
            font-weight: 600;
            color: var(--text-primary);
            position: sticky;
            top: 0;
            z-index: 10;
        }
        
        .clients-table tbody tr:hover {
            background: #f8f9fa;
        }
        
        .status-badge {
            display: inline-flex;
            align-items: center;
            padding: 0.25rem 0.75rem;
            border-radius: 50px;
            font-size: 0.75rem;
            font-weight: 500;
        }
        
        .status-active {
            background: #d1f2eb;
            color: #0c7b93;
        }
        
        .status-inactive {
            background: #fadbd8;
            color: #a93226;
        }
        
        .action-buttons {
            display: flex;
            gap: 0.5rem;
        }
        
        .btn-sm {
            padding: 0.4rem 0.8rem;
            font-size: 0.8rem;
            border-radius: 6px;
        }
        
        .btn-warning {
            background: linear-gradient(135deg, #ff9500, #ff8c00);
            color: white;
            box-shadow: 0 2px 8px rgba(255, 149, 0, 0.3);
        }
        
        .btn-danger {
            background: linear-gradient(135deg, #dc3545, #c82333);
            color: white;
            box-shadow: 0 2px 8px rgba(220, 53, 69, 0.3);
        }
        
        .btn-outline {
            background: transparent;
            border: 1px solid;
        }
        
        .btn-outline-primary {
            border-color: #0071e3;
            color: #0071e3;
        }
        
        .btn-outline-primary:hover {
            background: #0071e3;
            color: white;
        }
        
        @keyframes modalSlideIn {
            from {
                opacity: 0;
                transform: scale(0.9) translateY(-50px);
            }
            to {
                opacity: 1;
                transform: scale(1) translateY(0);
            }
        }
        
        .loading-spinner {
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 3rem;
        }
        
        .spinner {
            width: 40px;
            height: 40px;
            border: 4px solid #f3f3f3;
            border-top: 4px solid var(--nhis-primary);
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <!-- Animated Background -->
    <div class="animated-bg">
        <div class="bg-shape bg-shape-1"></div>
        <div class="bg-shape bg-shape-2"></div>
    </div>

    <div class="app-container">
        <!-- Header -->
        <header class="app-header">
            <h1 class="app-title">
                <div class="app-logo">
                    <i class="fas fa-file-medical"></i>
                </div>
                Smart Claims
            </h1>
            
            <div class="user-menu relative">
                <div class="user-button cursor-pointer" id="userMenuButton">
                    <div class="user-avatar">
                        <i class="fas fa-user"></i>
                    </div>
                    <span class="hidden md:inline"><?php echo htmlspecialchars($user['full_name'] ?? 'User'); ?></span>
                    <i class="fas fa-chevron-down ml-2 text-xs"></i>
                </div>
                <div id="userDropdown" class="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg py-2 z-50 hidden">
                    <a href="profile.php" class="block px-4 py-2 text-gray-800 hover:bg-gray-100">
                        <i class="fas fa-user-circle mr-2"></i> Profile
                    </a>
                    <a href="settings.php" class="block px-4 py-2 text-gray-800 hover:bg-gray-100">
                        <i class="fas fa-cog mr-2"></i> Settings
                    </a>
                    <div class="border-t border-gray-200 my-1"></div>
                    <a href="../logout.php" class="block px-4 py-2 text-red-600 hover:bg-gray-100">
                        <i class="fas fa-sign-out-alt mr-2"></i> Logout
                    </a>
                </div>
            </div>
        </header>
        
        <!-- Navigation -->
        <nav class="app-nav">
            <a href="dashboard.php" class="nav-item">
                <i class="fas fa-tachometer-alt"></i>
                <span>Dashboard</span>
            </a>
            <a href="client-registration.php" class="nav-item active">
                <i class="fas fa-user-plus"></i>
                <span>Client Registration</span>
            </a>
            <a href="service-requisition.php" class="nav-item">
                <i class="fas fa-clipboard-list"></i>
                <span>Service Requisition</span>
            </a>
            <a href="vital-signs.php" class="nav-item">
                <i class="fas fa-heartbeat"></i>
                <span>Vital Signs</span>
            </a>
            <a href="diagnosis-medication.php" class="nav-item">
                <i class="fas fa-stethoscope"></i>
                <span>Diagnosis & Medication</span>
            </a>
            <a href="claims-processing.php" class="nav-item">
                <i class="fas fa-file-invoice-dollar"></i>
                <span>Claims Processing</span>
            </a>
            <a href="reports.php" class="nav-item">
                <i class="fas fa-chart-bar"></i>
                <span>Reports</span>
            </a>
        </nav>
        
        <!-- Main Content -->
        <main>
            <!-- Page Header -->
            <div class="card">
                <div class="flex justify-between items-center">
                    <div>
                        <h2 class="card-title text-2xl font-bold mb-2">
                            <i class="fas fa-user-plus mr-2"></i>
                            NHIS Client Registration
                        </h2>
                        <p class="text-secondary text-lg">Register new clients with NHIS verification and demographic details</p>
                        <p class="text-sm text-gray-600 mt-2">All fields marked with <span class="text-orange-500">*</span> are required</p>
                    </div>
                    <div class="flex space-x-2">
                        <button class="btn btn-secondary" onclick="clearForm()">
                            <i class="fas fa-broom mr-2"></i>
                            Clear Form
                        </button>
                        <button type="button" class="btn btn-info" onclick="viewClients()">
                            <i class="fas fa-users mr-2"></i>
                            View Clients
                        </button>
                        <button class="btn btn-primary" onclick="verifyNHIS()">
                            <i class="fas fa-search mr-2"></i>
                            Verify NHIS
                        </button>
                    </div>
                </div>
            </div>

            <!-- Alert Messages -->
            <div id="alertContainer"></div>

            <!-- Client Registration Form -->
            <form id="clientRegistrationForm" class="space-y-6">
                <!-- NHIS Information Section -->
                <div class="card">
                    <h3 class="card-title text-xl font-bold mb-4">
                        <i class="fas fa-id-card mr-2"></i>
                        NHIS Information
                    </h3>
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="nhis_number" class="form-label">NHIS Number *</label>
                            <input type="text" 
                                   id="nhis_number" 
                                   name="nhis_number" 
                                   class="form-control" 
                                   placeholder="Enter NHIS number"
                                   pattern="[0-9]{10}"
                                   maxlength="10"
                                   required>
                            <small class="text-gray-500">10-digit NHIS membership number</small>
                        </div>
                        
                        <div class="form-group">
                            <label for="nhis_expiry" class="form-label">NHIS Expiry Date *</label>
                            <input type="date" 
                                   id="nhis_expiry" 
                                   name="nhis_expiry" 
                                   class="form-control" 
                                   required>
                        </div>
                        
                        <div class="form-group">
                            <label for="membership_type" class="form-label">Membership Type *</label>
                            <select id="membership_type" name="membership_type" class="form-control" required>
                                <option value="">Select membership type</option>
                                <option value="SSNIT_Contributor">SSNIT Contributor</option>
                                <option value="SSNIT_Pensioner">SSNIT Pensioner</option>
                                <option value="Informal_Sector">Informal Sector</option>
                                <option value="Indigent">Indigent</option>
                                <option value="Under_18">Under 18</option>
                                <option value="70_Above">70 years and above</option>
                                <option value="Pregnant_Women">Pregnant Women</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="policy_status" class="form-label">Policy Status</label>
                            <div id="policy_status" class="nhis-status nhis-pending">
                                <i class="fas fa-clock mr-2"></i>
                                Verification Pending
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Personal Information Section -->
                <div class="card">
                    <h3 class="card-title text-xl font-bold mb-4">
                        <i class="fas fa-user mr-2"></i>
                        Personal Information
                    </h3>
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="title" class="form-label">Title</label>
                            <select id="title" name="title" class="form-control">
                                <option value="">Select title</option>
                                <option value="Mr">Mr.</option>
                                <option value="Mrs">Mrs.</option>
                                <option value="Miss">Miss</option>
                                <option value="Dr">Dr.</option>
                                <option value="Prof">Prof.</option>
                                <option value="Rev">Rev.</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="first_name" class="form-label">First Name *</label>
                            <input type="text" 
                                   id="first_name" 
                                   name="first_name" 
                                   class="form-control" 
                                   placeholder="Enter first name"
                                   required>
                        </div>
                        
                        <div class="form-group">
                            <label for="middle_name" class="form-label">Middle Name</label>
                            <input type="text" 
                                   id="middle_name" 
                                   name="middle_name" 
                                   class="form-control" 
                                   placeholder="Enter middle name">
                        </div>
                        
                        <div class="form-group">
                            <label for="last_name" class="form-label">Last Name *</label>
                            <input type="text" 
                                   id="last_name" 
                                   name="last_name" 
                                   class="form-control" 
                                   placeholder="Enter last name"
                                   required>
                        </div>
                        
                        <div class="form-group">
                            <label for="date_of_birth" class="form-label">Date of Birth *</label>
                            <input type="date" 
                                   id="date_of_birth" 
                                   name="date_of_birth" 
                                   class="form-control" 
                                   required>
                        </div>
                        
                        <div class="form-group">
                            <label for="gender" class="form-label">Gender *</label>
                            <select id="gender" name="gender" class="form-control" required>
                                <option value="">Select gender</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="marital_status" class="form-label">Marital Status</label>
                            <select id="marital_status" name="marital_status" class="form-control">
                                <option value="">Select status</option>
                                <option value="Single">Single</option>
                                <option value="Married">Married</option>
                                <option value="Divorced">Divorced</option>
                                <option value="Widowed">Widowed</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="occupation" class="form-label">Occupation</label>
                            <input type="text" 
                                   id="occupation" 
                                   name="occupation" 
                                   class="form-control" 
                                   placeholder="Enter occupation">
                        </div>
                    </div>
                </div>

                <!-- Contact Information Section -->
                <div class="card">
                    <h3 class="card-title text-xl font-bold mb-4">
                        <i class="fas fa-address-card mr-2"></i>
                        Contact Information
                    </h3>
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="phone_primary" class="form-label">Primary Phone *</label>
                            <input type="tel" 
                                   id="phone_primary" 
                                   name="phone_primary" 
                                   class="form-control" 
                                   placeholder="0XX XXX XXXX"
                                   pattern="[0-9]{10}"
                                   required>
                        </div>
                        
                        <div class="form-group">
                            <label for="phone_secondary" class="form-label">Secondary Phone</label>
                            <input type="tel" 
                                   id="phone_secondary" 
                                   name="phone_secondary" 
                                   class="form-control" 
                                   placeholder="0XX XXX XXXX"
                                   pattern="[0-9]{10}">
                        </div>
                        
                        <div class="form-group">
                            <label for="email" class="form-label">Email Address</label>
                            <input type="email" 
                                   id="email" 
                                   name="email" 
                                   class="form-control" 
                                   placeholder="example@email.com">
                        </div>
                        
                        <div class="form-group">
                            <label for="emergency_contact" class="form-label">Emergency Contact</label>
                            <input type="tel" 
                                   id="emergency_contact" 
                                   name="emergency_contact" 
                                   class="form-control" 
                                   placeholder="Emergency contact number">
                        </div>
                    </div>
                </div>

                <!-- Address Information Section -->
                <div class="card">
                    <h3 class="card-title text-xl font-bold mb-4">
                        <i class="fas fa-map-marker-alt mr-2"></i>
                        Address Information
                    </h3>
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="region" class="form-label">Region *</label>
                            <select id="region" name="region" class="form-control" required>
                                <option value="">Select region</option>
                                <option value="Greater Accra">Greater Accra</option>
                                <option value="Ashanti">Ashanti</option>
                                <option value="Central">Central</option>
                                <option value="Eastern">Eastern</option>
                                <option value="Northern">Northern</option>
                                <option value="Upper East">Upper East</option>
                                <option value="Upper West">Upper West</option>
                                <option value="Volta">Volta</option>
                                <option value="Western">Western</option>
                                <option value="Western North">Western North</option>
                                <option value="Brong Ahafo">Brong Ahafo</option>
                                <option value="Bono East">Bono East</option>
                                <option value="Ahafo">Ahafo</option>
                                <option value="Savannah">Savannah</option>
                                <option value="North East">North East</option>
                                <option value="Oti">Oti</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="district" class="form-label">District *</label>
                            <input type="text" 
                                   id="district" 
                                   name="district" 
                                   class="form-control" 
                                   placeholder="Enter district"
                                   required>
                        </div>
                        
                        <div class="form-group">
                            <label for="town_city" class="form-label">Town/City *</label>
                            <input type="text" 
                                   id="town_city" 
                                   name="town_city" 
                                   class="form-control" 
                                   placeholder="Enter town or city"
                                   required>
                        </div>
                        
                        <div class="form-group">
                            <label for="postal_address" class="form-label">Postal Address</label>
                            <input type="text" 
                                   id="postal_address" 
                                   name="postal_address" 
                                   class="form-control" 
                                   placeholder="P.O. Box 123, City">
                        </div>
                        
                        <div class="form-group">
                            <label for="residential_address" class="form-label">Residential Address *</label>
                            <textarea id="residential_address" 
                                      name="residential_address" 
                                      class="form-control" 
                                      rows="3" 
                                      placeholder="Enter detailed residential address"
                                      required></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label for="landmark" class="form-label">Landmark</label>
                            <input type="text" 
                                   id="landmark" 
                                   name="landmark" 
                                   class="form-control" 
                                   placeholder="Near school, church, etc.">
                        </div>
                    </div>
                </div>

                <!-- Medical Information Section -->
                <div class="card">
                    <h3 class="card-title text-xl font-bold mb-4">
                        <i class="fas fa-heartbeat mr-2"></i>
                        Medical Information
                    </h3>
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="blood_group" class="form-label">Blood Group</label>
                            <select id="blood_group" name="blood_group" class="form-control">
                                <option value="">Select blood group</option>
                                <option value="A+">A+</option>
                                <option value="A-">A-</option>
                                <option value="B+">B+</option>
                                <option value="B-">B-</option>
                                <option value="AB+">AB+</option>
                                <option value="AB-">AB-</option>
                                <option value="O+">O+</option>
                                <option value="O-">O-</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="allergies" class="form-label">Known Allergies</label>
                            <textarea id="allergies" 
                                      name="allergies" 
                                      class="form-control" 
                                      rows="2" 
                                      placeholder="List any known allergies (drugs, food, etc.)"></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label for="chronic_conditions" class="form-label">Chronic Conditions</label>
                            <textarea id="chronic_conditions" 
                                      name="chronic_conditions" 
                                      class="form-control" 
                                      rows="2" 
                                      placeholder="List any chronic conditions (diabetes, hypertension, etc.)"></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label for="emergency_contact_name" class="form-label">Emergency Contact Name</label>
                            <input type="text" 
                                   id="emergency_contact_name" 
                                   name="emergency_contact_name" 
                                   class="form-control" 
                                   placeholder="Full name of emergency contact">
                        </div>
                        
                        <div class="form-group">
                            <label for="emergency_contact_relationship" class="form-label">Relationship</label>
                            <select id="emergency_contact_relationship" name="emergency_contact_relationship" class="form-control">
                                <option value="">Select relationship</option>
                                <option value="Spouse">Spouse</option>
                                <option value="Parent">Parent</option>
                                <option value="Child">Child</option>
                                <option value="Sibling">Sibling</option>
                                <option value="Friend">Friend</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                    </div>
                </div>

                <!-- Form Actions -->
                <div class="card">
                    <div class="flex justify-between items-center">
                        <div class="text-sm text-gray-600">
                            <i class="fas fa-shield-alt mr-1"></i>
                            All information is securely encrypted and NHIA compliant
                        </div>
                        <div class="flex space-x-3">
                            <button type="button" class="btn btn-secondary" onclick="saveDraft()">
                                <i class="fas fa-save mr-2"></i>
                                Save Draft
                            </button>
                            <button type="submit" class="btn btn-success">
                                <i class="fas fa-user-plus mr-2"></i>
                                Register Client
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </main>
        
        <!-- Mobile Navigation -->
        <div class="mobile-nav">
            <a href="dashboard.php" class="mobile-nav-item">
                <i class="fas fa-tachometer-alt"></i>
                <span>Dashboard</span>
            </a>
            <a href="client-registration.php" class="mobile-nav-item active">
                <i class="fas fa-user-plus"></i>
                <span>Clients</span>
            </a>
            <a href="service-requisition.php" class="mobile-nav-item">
                <i class="fas fa-clipboard-list"></i>
                <span>Services</span>
            </a>
            <a href="vital-signs.php" class="mobile-nav-item">
                <i class="fas fa-heartbeat"></i>
                <span>Vitals</span>
            </a>
            <a href="diagnosis-medication.php" class="mobile-nav-item">
                <i class="fas fa-stethoscope"></i>
                <span>Diagnosis</span>
            </a>
            <a href="claims-processing.php" class="mobile-nav-item">
                <i class="fas fa-file-invoice-dollar"></i>
                <span>Claims</span>
            </a>
            <a href="reports.php" class="mobile-nav-item">
                <i class="fas fa-chart-bar"></i>
                <span>Reports</span>
            </a>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Initialize form
            initializeForm();
            
            // Setup form validation
            setupFormValidation();
            
            // Setup NHIS verification
            setupNHISVerification();
        });

        // Initialize form with current date restrictions
        function initializeForm() {
            const today = new Date().toISOString().split('T')[0];
            const maxDate = new Date();
            maxDate.setFullYear(maxDate.getFullYear() - 120);
            const minDate = maxDate.toISOString().split('T')[0];
            
            // Set date restrictions
            document.getElementById('date_of_birth').max = today;
            document.getElementById('date_of_birth').min = minDate;
            
            // Set NHIS expiry minimum to today
            document.getElementById('nhis_expiry').min = today;
        }

        // Setup form validation
        function setupFormValidation() {
            const form = document.getElementById('clientRegistrationForm');
            
            form.addEventListener('submit', function(e) {
                e.preventDefault();
                
                if (validateForm()) {
                    registerClient();
                }
            });
            
            // Real-time validation
            const requiredFields = form.querySelectorAll('input[required], select[required], textarea[required]');
            requiredFields.forEach(field => {
                field.addEventListener('blur', validateField);
                field.addEventListener('input', validateField);
            });
        }

        // Validate individual field
        function validateField(e) {
            const field = e.target;
            const value = field.value.trim();
            
            // Remove existing validation classes
            field.classList.remove('border-red-500', 'border-green-500');
            
            if (field.hasAttribute('required') && !value) {
                field.classList.add('border-red-500');
                return false;
            }
            
            // Specific validations
            if (field.type === 'email' && value && !isValidEmail(value)) {
                field.classList.add('border-red-500');
                return false;
            }
            
            if (field.name === 'nhis_number' && value && !isValidNHIS(value)) {
                field.classList.add('border-red-500');
                return false;
            }
            
            if (field.type === 'tel' && value && !isValidPhone(value)) {
                field.classList.add('border-red-500');
                return false;
            }
            
            field.classList.add('border-green-500');
            return true;
        }

        // Validate entire form
        function validateForm() {
            const form = document.getElementById('clientRegistrationForm');
            const requiredFields = form.querySelectorAll('input[required], select[required], textarea[required]');
            let isValid = true;
            let firstInvalidField = null;
            
            requiredFields.forEach(field => {
                if (!validateField({ target: field })) {
                    isValid = false;
                    if (!firstInvalidField) {
                        firstInvalidField = field;
                    }
                }
            });
            
            // If validation failed, show alert and scroll to first invalid field
            if (!isValid && firstInvalidField) {
                showAlert('Please fill in all required fields correctly', 'warning');
                setTimeout(() => {
                    firstInvalidField.scrollIntoView({ 
                        behavior: 'smooth', 
                        block: 'center' 
                    });
                    firstInvalidField.focus();
                }, 300);
            }
            
            return isValid;
        }

        // Validation helper functions
        function isValidEmail(email) {
            return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
        }

        function isValidNHIS(nhisNumber) {
            return /^[0-9]{10}$/.test(nhisNumber);
        }

        function isValidPhone(phone) {
            return /^[0-9]{10}$/.test(phone);
        }

        // Setup NHIS verification
        function setupNHISVerification() {
            const nhisInput = document.getElementById('nhis_number');
            
            nhisInput.addEventListener('blur', function() {
                const nhisNumber = this.value.trim();
                if (nhisNumber && isValidNHIS(nhisNumber)) {
                    verifyNHISNumber(nhisNumber);
                }
            });
        }

        // Verify NHIS number
        function verifyNHIS() {
            const nhisNumber = document.getElementById('nhis_number').value.trim();
            
            if (!nhisNumber) {
                showAlert('Please enter NHIS number first', 'warning');
                // Focus on NHIS input field
                document.getElementById('nhis_number').focus();
                return;
            }
            
            if (!isValidNHIS(nhisNumber)) {
                showAlert('Please enter a valid 10-digit NHIS number', 'danger');
                // Focus on NHIS input field
                document.getElementById('nhis_number').focus();
                return;
            }
            
            verifyNHISNumber(nhisNumber);
        }

        // Verify NHIS number with API
        function verifyNHISNumber(nhisNumber) {
            const statusDiv = document.getElementById('policy_status');
            statusDiv.className = 'nhis-status nhis-pending';
            statusDiv.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Verifying...';
            
            // Simulate API call to NHIA
            setTimeout(() => {
                // Mock verification response
                const isValid = Math.random() > 0.3; // 70% chance of valid
                
                if (isValid) {
                    statusDiv.className = 'nhis-status nhis-active';
                    statusDiv.innerHTML = '<i class="fas fa-check-circle mr-2"></i>Active Policy';
                    showAlert('NHIS number verified successfully', 'success');
                    
                    // Auto-fill some data (mock)
                    const expiryDate = new Date();
                    expiryDate.setFullYear(expiryDate.getFullYear() + 1);
                    document.getElementById('nhis_expiry').value = expiryDate.toISOString().split('T')[0];
                } else {
                    statusDiv.className = 'nhis-status nhis-expired';
                    statusDiv.innerHTML = '<i class="fas fa-exclamation-triangle mr-2"></i>Invalid/Expired';
                    showAlert('NHIS number is invalid or expired', 'danger');
                }
            }, 2000);
        }

        // Register client
        async function registerClient() {
            const formData = new FormData(document.getElementById('clientRegistrationForm'));
            const button = document.querySelector('button[type="submit"]');
            
            // Show loading state
            button.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Registering...';
            button.disabled = true;
            
            try {
                // Convert FormData to JSON
                const data = {};
                for (let [key, value] of formData.entries()) {
                    data[key] = value;
                }
                
                // Make API call to register patient
                const response = await fetch('../patients.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(data)
                });
                
                const result = await response.json();
                
                if (result.status === 'success') {
                    showAlert(`Client registered successfully! Client ID: ${result.data.id}`, 'success');
                    
                    // Clear any saved draft on successful registration
                    localStorage.removeItem('clientDraft');
                    
                    // Reset form after success
                    setTimeout(() => {
                        if (confirm('Would you like to register another client?')) {
                            clearForm();
                            // Scroll to top of form for new registration
                            document.getElementById('clientRegistrationForm').scrollIntoView({ 
                                behavior: 'smooth', 
                                block: 'start' 
                            });
                        } else {
                            window.location.href = 'dashboard.php';
                        }
                    }, 2000);
                } else {
                    showAlert(`Registration failed: ${result.message}`, 'danger');
                }
                
            } catch (error) {
                console.error('Registration error:', error);
                showAlert('Registration failed. Please check your connection and try again.', 'danger');
            }
            
            // Reset button
            button.innerHTML = '<i class="fas fa-user-plus mr-2"></i>Register Client';
            button.disabled = false;
        }

        // Save draft
        function saveDraft() {
            const formData = new FormData(document.getElementById('clientRegistrationForm'));
            
            // Save to localStorage as draft
            const draftData = {};
            for (let [key, value] of formData.entries()) {
                draftData[key] = value;
            }
            
            localStorage.setItem('clientDraft', JSON.stringify(draftData));
            showAlert('Draft saved successfully', 'success');
        }

        // Clear form
        function clearForm() {
            if (confirm('Are you sure you want to clear all form data?')) {
                document.getElementById('clientRegistrationForm').reset();
                
                // Reset NHIS status
                const statusDiv = document.getElementById('policy_status');
                statusDiv.className = 'nhis-status nhis-pending';
                statusDiv.innerHTML = '<i class="fas fa-clock mr-2"></i>Verification Pending';
                
                // Clear validation classes
                document.querySelectorAll('.border-red-500, .border-green-500').forEach(el => {
                    el.classList.remove('border-red-500', 'border-green-500');
                });
                
                // Clear any saved draft
                localStorage.removeItem('clientDraft');
                
                showAlert('Form cleared successfully', 'success');
                
                // Scroll to top of form
                setTimeout(() => {
                    document.getElementById('clientRegistrationForm').scrollIntoView({ 
                        behavior: 'smooth', 
                        block: 'start' 
                    });
                }, 300);
            }
        }

        // Show alert message
        function showAlert(message, type, autoScroll = true) {
            const alertContainer = document.getElementById('alertContainer');
            const alertDiv = document.createElement('div');
            alertDiv.className = `alert alert-${type}`;
            alertDiv.innerHTML = `
                <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'warning' ? 'exclamation-triangle' : 'exclamation-circle'} mr-2"></i>
                ${message}
            `;
            
            alertContainer.appendChild(alertDiv);
            
            // Auto-scroll to show the alert
            if (autoScroll) {
                setTimeout(() => {
                    alertContainer.scrollIntoView({ 
                        behavior: 'smooth', 
                        block: 'start',
                        inline: 'nearest'
                    });
                }, 100);
            }
            
            // Auto-remove after 5 seconds
            setTimeout(() => {
                alertDiv.remove();
            }, 5000);
        }

        // Load draft on page load
        window.addEventListener('load', function() {
            const draft = localStorage.getItem('clientDraft');
            if (draft) {
                const draftData = JSON.parse(draft);
                
                if (confirm('A draft was found. Would you like to load it?')) {
                    Object.keys(draftData).forEach(key => {
                        const field = document.getElementById(key);
                        if (field) {
                            field.value = draftData[key];
                        }
                    });
                    
                    showAlert('Draft loaded successfully', 'success');
                }
            }
        });

        // View Clients Modal Functions
        function viewClients() {
            const modal = document.getElementById('viewClientsModal');
            modal.classList.add('show');
            document.body.style.overflow = 'hidden';
            loadClients();
        }

        function closeClientsModal() {
            const modal = document.getElementById('viewClientsModal');
            modal.classList.remove('show');
            document.body.style.overflow = 'auto';
        }

        // Close modal when clicking outside
        document.getElementById('viewClientsModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeClientsModal();
            }
        });

        // Load clients data
        async function loadClients() {
            const container = document.getElementById('clientsTableContainer');
            container.innerHTML = '<div class="loading-spinner"><div class="spinner"></div></div>';

            try {
                const response = await fetch('../patients.php');
                const result = await response.json();

                if (result.status === 'success') {
                    displayClientsTable(result.data.patients || []);
                } else {
                    container.innerHTML = '<div class="text-center py-8"><p class="text-red-500">Error loading clients: ' + result.message + '</p></div>';
                }
            } catch (error) {
                console.error('Error loading clients:', error);
                container.innerHTML = '<div class="text-center py-8"><p class="text-red-500">Error loading clients. Please try again.</p></div>';
            }
        }

        function displayClientsTable(clients) {
            const container = document.getElementById('clientsTableContainer');
            
            if (clients.length === 0) {
                container.innerHTML = `
                    <div class="text-center py-8">
                        <i class="fas fa-users text-gray-400 text-4xl mb-4"></i>
                        <p class="text-gray-500 text-lg">No clients registered yet</p>
                        <p class="text-gray-400">Register your first client to get started</p>
                    </div>
                `;
                return;
            }

            const tableHTML = `
                <table class="clients-table">
                    <thead>
                        <tr>
                            <th>Patient #</th>
                            <th>Name</th>
                            <th>NHIS Number</th>
                            <th>Gender</th>
                            <th>Phone</th>
                            <th>Date Registered</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${clients.map(client => `
                            <tr>
                                <td><strong>${client.patient_number || client.id}</strong></td>
                                <td>
                                    <div>
                                        <strong>${client.first_name} ${client.last_name}</strong>
                                        ${client.other_names ? '<br><small class="text-gray-500">' + client.other_names + '</small>' : ''}
                                    </div>
                                </td>
                                <td>${client.nhis_number || 'N/A'}</td>
                                <td>
                                    <span class="flex items-center">
                                        <i class="fas fa-${client.gender === 'Female' ? 'venus' : 'mars'} mr-1 text-${client.gender === 'Female' ? 'pink' : 'blue'}-500"></i>
                                        ${client.gender}
                                    </span>
                                </td>
                                <td>${client.phone || client.phone_primary || 'N/A'}</td>
                                <td>${formatDate(client.created_at)}</td>
                                <td>
                                    <span class="status-badge ${client.is_active == 1 ? 'status-active' : 'status-inactive'}">
                                        <i class="fas fa-${client.is_active == 1 ? 'check-circle' : 'times-circle'} mr-1"></i>
                                        ${client.is_active == 1 ? 'Active' : 'Inactive'}
                                    </span>
                                </td>
                                <td>
                                    <div class="action-buttons">
                                        <button class="btn btn-outline-primary btn-sm" onclick="viewClientDetails(${client.id})" title="View Details">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button class="btn btn-warning btn-sm" onclick="editClient(${client.id})" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="btn btn-danger btn-sm" onclick="deleteClient(${client.id}, '${client.first_name} ${client.last_name}')" title="Delete">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            `;

            container.innerHTML = tableHTML;
        }

        function formatDate(dateString) {
            if (!dateString) return 'N/A';
            const date = new Date(dateString);
            return date.toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'short',
                day: 'numeric'
            });
        }

        function refreshClients() {
            loadClients();
        }

        function exportClients() {
            showAlert('Export functionality will be implemented soon', 'info');
        }

        function viewClientDetails(clientId) {
            showAlert('View details functionality will be implemented soon', 'info');
        }

        function editClient(clientId) {
            showAlert('Edit functionality will be implemented soon', 'info');
        }

        async function deleteClient(clientId, clientName) {
            if (!confirm(`Are you sure you want to delete ${clientName}? This action cannot be undone.`)) {
                return;
            }

            try {
                const response = await fetch(`../patients.php?id=${clientId}`, {
                    method: 'DELETE'
                });

                const result = await response.json();

                if (result.status === 'success') {
                    showAlert('Client deleted successfully', 'success');
                    loadClients(); // Refresh the table
                } else {
                    showAlert('Failed to delete client: ' + result.message, 'danger');
                }
            } catch (error) {
                console.error('Error deleting client:', error);
                showAlert('Error deleting client. Please try again.', 'danger');
            }
        }
    </script>

    <!-- View Clients Modal -->
    <div id="viewClientsModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">
                    <i class="fas fa-users mr-2"></i>
                    Registered Clients
                </h3>
                <button class="modal-close" onclick="closeClientsModal()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body">
                <div class="flex justify-between items-center mb-4">
                    <div>
                        <p class="text-gray-600">View and manage all registered clients</p>
                    </div>
                    <div class="flex space-x-2">
                        <button class="btn btn-outline-primary btn-sm" onclick="refreshClients()">
                            <i class="fas fa-sync-alt mr-1"></i>
                            Refresh
                        </button>
                        <button class="btn btn-primary btn-sm" onclick="exportClients()">
                            <i class="fas fa-download mr-1"></i>
                            Export
                        </button>
                    </div>
                </div>
                
                <div id="clientsTableContainer">
                    <div class="loading-spinner">
                        <div class="spinner"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>